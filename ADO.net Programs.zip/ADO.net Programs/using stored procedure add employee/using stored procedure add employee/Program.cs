﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

//Including namespace for ado.net
using System.Data.SqlClient;
namespace AddEmployeeRecord
{
    class Program
    {

        static void Main(string[] args)
        {
            int iEmpId;
            string sName, sCity;
            //iEmpId = Convert.ToInt32(Console.ReadLine());
            //sName = Console.ReadLine();
            //sCity = Console.ReadLine();
            SqlConnection con = new SqlConnection(@"Server =INBASDPC11306;Database =dbEmployee; Integrated Security=false;uid=sa;pwd=System123");
            //SqlCommand cmd = new SqlCommand();

            Console.WriteLine("Enter Employee Details \n");

            //for using the stored procedure
            //cmd.CommandText = "prcAddRecord";
            //cmd.CommandType = CommandType.StoredProcedure;
            // ins place of above two lines we can write 
            SqlCommand cmd = new SqlCommand("exec prcAddRecord @id,@Name,@city");

            iEmpId = Convert.ToInt32(Console.ReadLine());
            sName = Console.ReadLine();
            sCity = Console.ReadLine();

            cmd.Parameters.Add("@id", iEmpId);
            cmd.Parameters.Add("@name", sName);
            cmd.Parameters.Add("@city", sCity);

            con.Open();
            cmd.Connection = con;

            cmd.ExecuteNonQuery();
        }
    }
}
