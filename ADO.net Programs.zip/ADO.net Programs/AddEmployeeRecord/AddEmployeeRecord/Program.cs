﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Including namespace for ado.net
using System.Data.SqlClient;
namespace AddEmployeeRecord
{
    class Program
    {

        static void Main(string[] args)
        {
            int iEmpId;
            string sName, sCity;
            Console.WriteLine("Enter Employee Details \n");
            iEmpId = Convert.ToInt32(Console.ReadLine());
            sName = Console.ReadLine();
            sCity = Console.ReadLine();
            //Establishing connection with the database
            SqlConnection con = new SqlConnection(@"Server =INBASDPC11306;Database =dbEmployee;Integrated Security = false;uid=sa;pwd=System123");
            //Integrated security = true for windows authentication
            //and for sql server authentication Integrated security = false
            //creating sqlcommand object to store the insert command
            SqlCommand cmd = new SqlCommand("insert into tblEmployee values(@id,@name,@city)");//these are sql parameter @stands for sql parameter
            //set connection property of the command object

            con.Open();
            cmd.Connection = con;

            //set the values for sql parameters
            cmd.Parameters.Add("@id", iEmpId);
            cmd.Parameters.Add("@name", sName);
            cmd.Parameters.Add("@city", sCity);

            //to execute command
            cmd.ExecuteNonQuery();
        }
    }
}
