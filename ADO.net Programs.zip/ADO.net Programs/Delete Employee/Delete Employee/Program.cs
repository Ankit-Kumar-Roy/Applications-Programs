﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Including namespace for ado.net
using System.Data.SqlClient;
namespace DeleteEmployeeRecord
{
    class Program
    {
    
        static void Main(string[] args)
        {
            int iEmpId;
            string sName, sCity;
            Console.WriteLine("Enter ID of the Employee whose Details you want to delete\n");
            iEmpId = Convert.ToInt32(Console.ReadLine());

            //Establishing connection with the database
            SqlConnection con = new SqlConnection(@"Server =INBASDPC11306;Database =dbEmployee;Integrated Security = false;uid=sa;pwd=System123");
            //Integrated security = true for windows authentication
            //and for sql server authentication Integrated security = false
            //creating sqlcommand object to store the delete command
            SqlCommand cmd = new SqlCommand("delete from tblEmployee where iEmpId=@id");//these are sql parameter @stands for sql parameter
            //set connection property of the command object

            con.Open();
            cmd.Connection = con;

            cmd.Parameters.Add("@id", iEmpId);

            //to execute command
            cmd.ExecuteNonQuery();
            Console.WriteLine("Query Executed successfully, Press an key to exit");
            Console.Read();
        }
    }
}
