﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Stored_Procedure_ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            int iEmpID,iDispEmpID;
            string sName, sCity;
            Console.WriteLine("Enter Employee Details i.e ID , Name and City");
            iEmpID = Convert.ToInt32(Console.ReadLine());
            sName = Console.ReadLine();
            sCity = Console.ReadLine();
            SqlConnection conn = new SqlConnection(@"Server = INBASDPC11306; Database = dbEmployee;uid = sa; pwd = System123");
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("prcAddRecord", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@id", iEmpID));
                cmd.Parameters.Add(new SqlParameter("@name", sName));
                cmd.Parameters.Add(new SqlParameter("@city", sCity));
                cmd.ExecuteNonQuery();
                Console.WriteLine("Enter Employee ID whose Details you want to display");
                iDispEmpID = Convert.ToInt32(Console.ReadLine());
                SqlCommand cmd1 = new SqlCommand("dispRecord", conn);
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Parameters.Add(new  SqlParameter("@iid", iDispEmpID));
                SqlDataReader rdr;
                rdr = cmd1.ExecuteReader();
                while(rdr.Read())
                {
                    int x = (int)rdr[0];
                    string y = (string)rdr[1];
                    string z = (string)rdr[2];
                    Console.WriteLine("Employee ID = {0},Employee Name = {1},Employee City = {2}", x, y, z);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if(conn!=null)
                {
                    conn.Close();
                }
            }
            Console.WriteLine("Query Executed Successfully.......Press any key to EXIT");
            Console.ReadKey();
        }
    }
}
