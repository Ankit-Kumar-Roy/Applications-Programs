﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Reading_Data_Using_DataReader
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection(@"Server =INBASDPC11306;Database =dbEmployee;Integrated Security =false;uid=sa;pwd=System123");
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select sName from tblEmployee";
            con.Open();
            cmd.Connection = con;

            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows)
                {
                    Console.WriteLine(dr[0]);
                }
            }
            Console.Read();
        }
    }
}
