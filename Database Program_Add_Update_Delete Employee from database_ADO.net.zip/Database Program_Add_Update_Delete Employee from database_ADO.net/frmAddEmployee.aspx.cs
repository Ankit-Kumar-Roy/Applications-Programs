﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class frmAddEmployee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(@"Server = INBASDPC11306;DataBase = dbEmployee;uid=sa;pwd=System123");

        SqlCommand cmd = new SqlCommand("Insert into tblEmployee values(@id,@name,@city)",conn);
        cmd.Parameters.Add("@id", txtid.Text);
        cmd.Parameters.Add("@name", txtname.Text);
        cmd.Parameters.Add("@city", txtcity.Text);
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }
}