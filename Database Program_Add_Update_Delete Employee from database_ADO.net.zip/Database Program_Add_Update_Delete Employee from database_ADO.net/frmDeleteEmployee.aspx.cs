﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class frmDeleteEmployee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(@"Server = INBASDPC11306;DataBase = dbEmployee;uid=sa;pwd=System123");

        SqlCommand cmd = new SqlCommand("Delete from tblEmployee where iEmpId = @deleteid", conn);
        cmd.Parameters.Add("@deleteid", txtEmpId.Text);
        conn.Open();
        try
        {
            cmd.ExecuteNonQuery();            
        }
        catch
        {
            Console.WriteLine("!!!!!!!!!......Something happened");
        }
        conn.Close(); 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        txtMsg.Text = "Employee Deleted Successfully";
    }
}