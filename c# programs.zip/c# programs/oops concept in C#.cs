﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
      
            //object oriented program using c#

            class Person
            {
                private string myName;
                private int myAge;
                private char mySex;

                public Person(){} //default constructor

                //parameterised constructor
                public Person(string name,int age,char sex)
                {
                    this.myName=name;
                    this.myAge=age;
                    this.mySex=sex;
                }

                //this is called as a property

                public string Name
                {
                    get //Accessors
                    {
                        return myName;
                    }
                    set
                    {
                        myName=value;
                    }

                }
  
                public int Age
                {
                    get
                    {
                        return myAge;
                    }
                    set
                    {
                        myAge=value;
                    }
                }

                public char Sex
                {
                    get
                    {
                        return mySex;
                    }
                    set
                    {
                        mySex=value;
                    }
                }

                public override string ToString()
                {
                    return "Name=" + Name + ",Age" + Age + ",Sex=" + Sex;
                }
                public override bool Equals(object o)
                {
                    if((myName==((Person)o).myName)&&(mySex==((Person)o).myAge)&&(mySex==((Person)o).mySex))
                        return true;
                    else return false;
                }
                public static void Main()
                {
                    Person p1=new Person();
                    p1.Name="Joe";
                    p1.Age=99;
                    p1.Sex='m';
                    Console.WriteLine("person details {0}",p1);

                    Person p2=new Person();
                    p2.Name="Jane";
                    p2.Age=31;
                    p2.Sex='f';
                    Console.WriteLine("person details {0}",p2);

                    Person p3=new Person();
                    p3.Name="Jane";
                    p3.Age=31;
                    p3.Sex='f';
                    Console.WriteLine("person details {0}",p3);

                    bool same = p2.Equals(p3);
                    Console.WriteLine("same person" +same);

                    //making use of parameterised constructor
                    Person p4= new Person("otto",42,'m');
                    Console.WriteLine("Person details" +p4.myName);
                    Console.WriteLine("Person details" +p4.mySex);

                    //array of persons
                    Person[] pmany=new Person[2];
                    pmany[0]=new Person("Car1",23,'m');
                    pmany[1]=new Person("Ola",7,'f');

                    Console.WriteLine("name of person[0]" + pmany[0]);
                    Console.WriteLine("name of person[0]" +pmany[0].myName);
                    Console.WriteLine("sex of the person[1]"+ pmany[1].mySex);
                    Console.Read();

                }

            }
        }
    }


