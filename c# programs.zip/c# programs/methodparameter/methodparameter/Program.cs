﻿using System;

    class Program
    {
        static void Main(string[] args)
        {
            int Total=0;
            int Product=0;
            Calculate(10, 20, out Total, out Product);
            Console.WriteLine("Sum = {0} and Product ={1}", Total, Product);
            Console.Read();
        }
        public static void Calculate(int FN,int SN,out int sum,out int product)
        {
                  sum = FN + SN;
                  product = FN * SN;
        }
   }
  










