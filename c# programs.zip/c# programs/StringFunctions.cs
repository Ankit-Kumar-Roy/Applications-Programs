﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace samp1
{
    class Program
    {
        static void Main(string[] args)
        {
            

            // String manipulation functions
     StringBuilder str;
      str = new StringBuilder("Ritu");
      Console.WriteLine(str);
        //str1 = "Ritu ";
            str.Insert(4, "Rajastan");
            Console.WriteLine(str);
            str.Append("Somani");
            Console.WriteLine(str);
            str.Remove(5, 5);
            Console.WriteLine(str);
        }
    }
}
