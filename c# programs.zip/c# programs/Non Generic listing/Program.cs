﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Non_Generic_listing
{
    //non generic listing

    public class CustomStack
    {
        const int size = 10;
        private object[] register;
        private int count = 0;

        private CustomStack()
        {
            register = new object[size];

        }
        public void Push (object x) //boxing
        {
            if (count < size)
                register[count++] = x;
        }
        public object Pop()
        {
            return register[--count];
        }

        static void Main()
        {
            CustomStack intStack = new CustomStack();
            intStack.Push(10);
            int i = (int)intStack.Pop(); //unboxing
            Console.WriteLine(i);
            Console.Read();
        }

        }
    }
