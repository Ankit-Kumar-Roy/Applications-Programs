﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        public void div(int n1, int n2)
        {
            int r;
            r = n1 / n2;
            Console.WriteLine(r);
        }
        static void Main(string[] args)
        {
            int n1, n2;
            int[] mark;
            mark = new int[2];
            n1 = Convert.ToInt32(Console.ReadLine());
            n2 = Convert.ToInt32(Console.ReadLine());

            try
            {
                Program obj = new Program();
                obj.div(n1, n2);
                try
                {
                    mark[0] = 12;
                    mark[1] = 11;
                    mark[2] = 15;
                }
                catch (IndexOutOfRangeException e)
                {
                    Console.WriteLine("Wrong access to array element");
                }
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Division by zero is not allowed inMain" + e);
            }
            finally
            {
                Console.WriteLine("Executing finally block");
            }
            Console.Read();
        }
    }
}
