﻿using System;
using System.Collections.Generic;
using System.Text;


//String Builder Program

    class Program
    {
        static void Main(string[] args)
        {
            string s = "Car1";
            StringBuilder b1 = new StringBuilder(s.Length + 12);
            StringBuilder b5 = new StringBuilder();
            Console.WriteLine(b5.MaxCapacity);
            Console.WriteLine(b1.Capacity);

            b1.Append("Car1");
            b1.Append("-uli");
            b1.AppendLine();//to add a line to the end of the string

            Console.WriteLine(b1);
            b1.Remove(3, 2);
            Console.WriteLine(b1); //caruli
            StringBuilder b2 = new StringBuilder("A.C");
            b2.Insert(2, "B.");
            Console.WriteLine(b2); //A:B:C
            b2.Replace('.', ':');
            Console.WriteLine(b2); //A:B:C
            StringBuilder b3 = new StringBuilder("stringbuilder");
            b3.Remove(4, 9);
            Console.WriteLine(b3);
            Console.ReadKey();

        }
    }
