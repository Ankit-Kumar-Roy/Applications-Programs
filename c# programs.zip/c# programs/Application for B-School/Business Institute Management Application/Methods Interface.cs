﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Institute_Management_Application
{
    interface Methods
    {
        void addStudent();
        void removeStudent();
        void getStudent();
        void getAllStudents();
        void addDepartment();
        void removeDepartment();
        void getDepartment();
        void getAllDepartment();
    }
}
