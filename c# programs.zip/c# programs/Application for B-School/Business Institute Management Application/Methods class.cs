﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Institute_Management_Application
{
    public class Methods_class
    {
        public static void addStudent()
        {
            Student stu = new Student();
            Console.WriteLine("Enter Student Name");
            stu.name = Console.ReadLine();
            Console.WriteLine("Enter student ID");
            stu.studentID = Convert.ToInt32(Console.ReadLine());
            if (students.Count > 0)
            {
                if (students.Exists(cust => cust.studentID == stu.studentID))
                {
                    Console.WriteLine("Entered student details exists enter another student Details");
                }
                else
                {
                    students.Add(stu);
                }
            }
            else
            {
                students.Add(stu);
            }
            int y = mainMenu();
            mainMethod(y);
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------
        public static void removeStudent()
        {
            Console.WriteLine("Enter the student ID whose details u want to delete");
            int id1 = Convert.ToInt32(Console.ReadLine());
            Student stu = students.Find(cust => cust.studentID == id1);
            students.Remove(stu);
            int y = mainMenu();
            mainMethod(y);
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------
        public static void getStudent()
        {
            Console.WriteLine("Enter the ID of the student whose details u want to dispaly");
            int id1 = Convert.ToInt32(Console.ReadLine());
            Student stu = students.Find(cust => cust.studentID == id1);
            Console.WriteLine("Name = {0} && studentID = {1}", stu.name, stu.studentID);
            int y = mainMenu();
            mainMethod(y);
        }
        //--------------------------------------------------------------------------------------------------------------------------------------------------
        public static void getAllStudents()
        {
            foreach (Student stu in students)
            {
                Console.WriteLine("Name = {0} && studentID = {1}", stu.name, stu.studentID);
            }
            int y = mainMenu();
            mainMethod(y);
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------------
        public static void addDepartment()
        {
            Console.WriteLine("Enter the department name which u want to add");
            Department dep = new Department();
            dep.name = Console.ReadLine();
            departmentname.Add(dep);
            int y = mainMenu();
            mainMethod(y);
        }
        //---------------------------------------------------------------------------------------------------------------
        public static void removeDepartment()
        {
            Console.WriteLine("Enter the department name which u want to remove");
            Department dep = new Department();
            dep.name = Console.ReadLine();
            departmentname.Remove(dep);
            int y = mainMenu();
            mainMethod(y);
        }
        //---------------------------------------------------------------------------------------------------------------------------
        public static void getDepartment()
        {
            Console.WriteLine("Enter the ID of the student whose details u want to dispaly");
            int id1 = Convert.ToInt32(Console.ReadLine());
            Student stu = students.Find(cust => cust.studentID == id1);
            Console.WriteLine("Name = {0} && studentID = {1}", stu.name, stu.studentID);
            int y = mainMenu();
            mainMethod(y);
        }
        //-----------------------------------------------------------------------
        public static void getAllDepartment()
        {
            Console.WriteLine("Enter the ID of the student whose details u want to dispaly");
            int id1 = Convert.ToInt32(Console.ReadLine());
            Student stu = students.Find(cust => cust.studentID == id1);
            Console.WriteLine("Name = {0} && studentID = {1}", stu.name, stu.studentID);
            int y = mainMenu();
            mainMethod(y);
        }
        //----------------------------------------------------------------------------------------------
    }
}
