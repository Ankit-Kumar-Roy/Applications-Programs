﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;

namespace Business_Institute_Management_Application
{
    public class Department
    {
        public string name;
        ArrayList dep1 = new ArrayList();
        ArrayList dep2 = new ArrayList();
        public  string info()
        {
            Console.WriteLine("Do you want to make changes in Finance and Accounts section -> type yes or no");
            string x= (Console.ReadLine()).ToUpper();
            return x;
        }
        public  void addInstructor()
        {
            dep1.Add("Rahul");
            dep1.Add("Aniket");
            dep1.Add("Supriya");
            dep1.Add("Manish");
        }
        public  void removeInstructor()
        {
            Console.WriteLine("Enter the name of the instructor you want to remove");
            string x1 = Console.ReadLine();
            dep1.Remove(x1);
        }
        public  void getInstructor()
        {

        }
        public  void getAllInstructors()
        {

        }

    }
}
