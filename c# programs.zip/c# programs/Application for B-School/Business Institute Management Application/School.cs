﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Institute_Management_Application
{
    public class School
    {
        public string name;
        public string address;
        public int phone;
        public enum choice
        {
            add_Stu,
            rem_Stu,
            get_Stu,
            get_AllStudents,
            add_Dept,
            rem_Dept,
            get_Dept,
            get_AllDept,
            Exit
        }
        static List<Student> students = new List<Student>();
        static List<Department> departmentname = new List<Department>();

        public static void Main(string[] args)
        {
            int option = mainMenu();
            mainMethod(option);
            Console.Read();
        }

        public static int mainMenu()
        {
            Console.WriteLine("Please Enter your Choice \n1: to add a student\n2: to remove a student\n3: to get a student\n4: to display or get all students\n5: to add a department\n6: to remove department\n7: to get department\n8: to get all departments\n0: Exit");

            int option1 = Convert.ToInt32(Console.ReadLine());
            return (option1);
        }

        public static void mainMethod(int x)
        {
            Methods_class mclass = new Methods_class();
            choice selection = (choice)x;
            switch (selection)
            {
                case choice.add_Stu:
                    mclass.addStudent();
                    break;
                case choice.rem_Stu:
                    mclass.removeStudent();
                    break;
                case choice.get_Stu:
                    mclass.getStudent();
                    break;
                case choice.get_AllStudents:
                    mclass.getAllStudents();
                    break;
                case choice.add_Dept:
                    mclass.addDepartment();
                    break;
                case choice.rem_Dept:
                    mclass.removeDepartment();
                    break;
                case choice.get_Dept:
                    mclass.getDepartment();
                    break;
                case choice.get_AllDept:
                    mclass.getAllDepartment();
                    break;
                case choice.Exit:
                    Console.WriteLine("Thank u for using the portal");
                    break;
                default:
                    Console.WriteLine("You have Entered a wrong Choice");
                    Console.WriteLine("Do you want to Continue, Enter Yes or No");
                    string s = (Console.ReadLine()).ToUpper();
                    if (s == "YES")
                    {
                        int y = mainMenu();
                        mainMethod(y);

                    }
                    else
                    {
                        break;
                    }
                    break;
            }
        }
    }

}







