﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Institute_Management_Application
{
    public class Student
    {
        public string name;
        public int studentID;
    }
}
