﻿using System;
    class Class2
    {
        static void Main()
        {
            Console.WriteLine("Enter your FirstName");
            string FirstName = Console.ReadLine();
            Console.WriteLine("Enter your LastName");
            string LastName = Console.ReadLine();
            Console.WriteLine("Hello {0}, {1}",FirstName,LastName);
            Console.Read();
        }
    }
