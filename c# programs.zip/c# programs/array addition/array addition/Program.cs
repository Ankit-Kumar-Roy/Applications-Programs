﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2darray
{
    class Program
    {
        public static void Main()
        {
            int i, j;
            int[,] summatrix = new int[2, 2];
            int[,] matrix1 = { { 1, 2 }, { 3, 4 } }; //TYPE1
            int[,] matrix2 = new int[2, 2] { { 2, 2 }, { 4, 3 } };  //TYPE2

            Console.WriteLine("\nMatrix 1 : ");
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    Console.Write(matrix1[i, j] + "\t");

                }
                Console.WriteLine();
            }
            Console.WriteLine("\nMatrix 2 : ");
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    Console.Write(matrix2[i, j] + "\t");

                }
                Console.WriteLine();
            }


            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    summatrix[i, j] = matrix1[i, j] + matrix2[i, j];
                }
            }

            Console.WriteLine("\nsum of 2 matrices : ");
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    Console.Write(summatrix[i, j] + "\t");
                }
                Console.WriteLine();
            }

            Console.Read();
        }
    }
}
