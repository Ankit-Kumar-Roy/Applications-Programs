﻿using System;
    public class Class1
    {
        public static void Main()
        {
            Console.WriteLine("Enter your Name");
            string UserName = Console.ReadLine();
            Console.WriteLine("Hello " + UserName);
            Console.Read();
        }
    }
