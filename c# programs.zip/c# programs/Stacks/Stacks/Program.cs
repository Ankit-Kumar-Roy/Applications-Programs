﻿using System;
using System.Collections;

class Program
{
    static void Main(String[] args)
    {
        //Declaring a stack
        Stack st = new Stack();
        //Inserting an element at the top of the stack i.i. push operation
        st.Push("Pankaj");
        st.Push(1);
        st.Push(10.5);
        st.Push(true);
        st.Push('A');
        //get the number of elements contained in the stack
        Console.WriteLine("Count : {0}",st.Count);
        Console.WriteLine();
        //printing all the elements of the stack
        Console.WriteLine("Element in Stack : ");
        foreach(object obj in st)
            Console.WriteLine(obj);
        Console.WriteLine();
        //Returns the topmost element of the stack without removing 
        Console.WriteLine("Top most element of stack : {0}", st.Peek());
        Console.WriteLine();
        //Removes and returns the topmost element of the stack i.e. Pop operation
        object TopElement = st.Pop();
        Console.WriteLine("Removing top element of stack ={0} \n Now Top element of stack = {1}\n",TopElement,st.Peek());
        //Determines whwther an element is present in the stack or not
        if(st.Contains("Pankaj"))
            Console.WriteLine("Pankaj Found");
        else
            Console.WriteLine("Pankaj not Found");
        //Copies the stack to a new array(object)
        Object[] ob = st.ToArray();
        Console.WriteLine();
        foreach(object obj in ob)
            Console.WriteLine(obj);
        //Removes all the element from stack
        st.Clear();
        Console.WriteLine();
        Console.WriteLine("Count : {0}",st.Count);
        Console.ReadKey();

    }
}