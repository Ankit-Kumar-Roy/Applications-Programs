﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using MenuDriven_EmployeeApplication;

namespace MenuDriven_EmployeeApplication
{
    public class Program
    {
        static List<EmployeeClass> Employees = new List<EmployeeClass>();
        static void Main(string[] args)
        {
            int Option = Mainmenu();
            MainMethod(Option);
            Console.Read();
        }
        public static int Mainmenu()
        {
            Console.WriteLine("Please enter your selection and the options are:-");
            Console.WriteLine("1. For adding an Employee");
            Console.WriteLine("2. For the updation of Employee");
            Console.WriteLine("3. To Delete an Employee");
            Console.WriteLine("4. To Display the Employee List");
            Console.WriteLine("5.To Exit\n");

            int option = Convert.ToInt32(Console.ReadLine());
            return option;
        }
        public static void MainMethod(int x)
        {

            switch(x)
            {
                case 1:
                    Program.AddEmployee();           
                    break;
                case 2:
                    Program.EmpUpdate();
                    break;
                case 3:
                   Program.DeleteEmployee();
                   break;
                case 4:
                 Program.DisplayEmployee();
                 break; 
               case 5:
                 Console.WriteLine("Thank u for using the portal");
                 break;
               default:
                 Console.WriteLine("You have Entered a wrong Choice");
                 Console.WriteLine("Do you want to Continue, Enter Yes or No");
                 string s = (Console.ReadLine()).ToUpper();
                 if(s == "YES")
                 {
                     int y = Mainmenu();
                     MainMethod(y);

                 }
                 else
                 {
                     break;
                 }
                 break;
            }
        }
        //Adding Employees in the list
                    public static void AddEmployee()
                    {
                        EmployeeClass Emp = new EmployeeClass();
                        Console.WriteLine("Enter Employee Name");
                        Emp.Name = Console.ReadLine();
                        Console.WriteLine("Enter Employee ID");
                        Emp.ID = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Employee Salary");
                        Emp.Salary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter Employee Department");
                        Emp.Department = Console.ReadLine();
                        if (Employees.Count > 0)
                        {
                            if (Employees.Exists(cust => cust.ID == Emp.ID))
                            {
                                Console.WriteLine("Entered Employee details exists enter another Employee Details");
                            }
                            else
                            {
                                Employees.Add(Emp);
                            }
                        }
                        else
                        {
                            Employees.Add(Emp);
                        }
                        //Console.WriteLine("Do u w")
                        int y = Mainmenu();
                        MainMethod(y);
                    }
//---updation of Employee------------------------------------
               public static void EmpUpdate()
                       {
                           Console.WriteLine("Enter the ID of the Employee whose Details u have to update");
                           EmployeeClass Emp = new EmployeeClass();
                           int id = int.Parse(Console.ReadLine());
                           if (Employees.Exists(cust => cust.ID != id))
                           {
                               Console.WriteLine("Employee Details doesn't exists");
                           }
                           else
                           {
                               Console.WriteLine("Enter Employee Updated details");
                               Console.WriteLine("Enter Employee Name");
                               Emp.Name = Console.ReadLine();
                               Console.WriteLine("Enter Employee ID");
                               Emp.ID = Convert.ToInt32(Console.ReadLine());
                               Console.WriteLine("Enter Employee Salary");
                               Emp.Salary = Convert.ToDouble(Console.ReadLine());
                               Console.WriteLine("Enter Employee Department");
                               Emp.Department = Console.ReadLine();
                               EmployeeClass E1 = Employees.Find(cust => cust.ID == id);    
                               E1.Name = Emp.Name;
                               E1.ID = Emp.ID;                                                                     
                               E1.Salary = Emp.Salary;
                               E1.Department = Emp.Department;
                           }
                           int y = Mainmenu();
                           MainMethod(y);
                       }
//------------------deletion of Employee---------------------------------------------
                    public static void DeleteEmployee()
                      {
                          Console.WriteLine("Enter the Employee ID whose details u want to delete");
                          int id1 = Convert.ToInt32(Console.Read());
                          EmployeeClass Emp = Employees.Find(cust => cust.ID == id1);
                          Employees.Remove(Emp);
                          int y = Mainmenu();
                          MainMethod(y);
                      }
//-------------------display of Employee--------------------
                    public static void DisplayEmployee()
                    {
                        foreach (EmployeeClass emp in Employees)
                            Console.WriteLine("Employee name : {0}\n Employee ID : {1} \nEmployee Salary : {2}\n Employee Department : {3}\n",
                             emp.Name, emp.ID, emp.Salary, emp.Department);
                        int y = Mainmenu();
                        MainMethod(y);
                    }
//-----------------------------
    }
//-------End of class-----------------------
}
//----------End of namespace=------------------
  
    










