﻿using System;
namespace Interfaces
{
    interface IEmployee1
    {
        void Print1();
    }
    interface IEmployee2
    {
        void Print2();
    }

    class Program : IEmployee1, IEmployee2
    {
        public void Print1()
        {
            Console.WriteLine("Print1");
        }
        public void Print2()
        {
            Console.WriteLine("Print2");
        }
        static void Main(string[] args)
        {
            Program p1 = new Program();
            p1.Print1();
            p1.Print2();
            Console.Read();

        }
    }
}