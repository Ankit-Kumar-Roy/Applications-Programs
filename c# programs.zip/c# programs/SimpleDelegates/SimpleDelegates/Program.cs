﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleDelegates
{
    class Program
    {
        //defining delegates
        delegate void SimpleDelegate(string s);
        static void Main(string[] args)
        {
         //creating delegate object
            SimpleDelegate del = new SimpleDelegate(DisplayMessage);
            //invoking function through delegate
            del("Welcome to simple Delegates");
            Console.Read();
        }
        static void DisplayMessage(string s)
        {
            Console.WriteLine("Simple Delegate");
        }
    }
}
