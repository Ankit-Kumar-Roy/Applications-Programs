﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflection_Program
{
    class Program
    {
        static void Main(string[] args)
        {
            string testclass = "System.Reflection.PropertyInfo";
            Console.WriteLine("Following is the information of {0} class", testclass);
            Console.ReadKey();
            Type MyType = Type.GetType(testclass);
            MemberInfo[] MyMemberInfoArray = MyType.GetMembers();
            //get the member types methods and dispaly the elements

            Console.WriteLine("\nThere are{0} members in {1}",
            MyMemberInfoArray.GetLength(0), MyType.FullName);

            for(int counter = 0;counter<MyMemberInfoArray.GetLength(0);counter++)
            {
                Console.WriteLine("{0}. {1} Member type - {2}",counter,MyMemberInfoArray[counter].Name,
                MyMemberInfoArray[counter].MemberType.ToString());
            }
            Console.Read();

        }
    }
}
