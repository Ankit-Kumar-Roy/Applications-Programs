﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace enum_and_switch_case
{
    public class Program
    {
        public static void Main()
        {
            Customer[] customers = new Customer[3];

            customers[0] = new Customer
            {
                name = "Mary",
                gender = Gender.Female
            };
            customers[1] = new Customer
            {
                name = "Tony",
                gender = Gender.Male
            };
            customers[2] = new Customer
            {
                name = "Scofield",
                gender = Gender.Unknown
            };
            Console.WriteLine("Customer Details are:-");
            foreach(Customer x in customers)
            {
                Console.WriteLine("Name : {0} and Gender : {1}", x.name,GetGender(x.gender));
            }
            Console.Read();
        }
        public static string GetGender(Gender gender)
        {
            switch (gender)
            {
                case Gender.Unknown:
                    return "Unknown";
                case Gender.Male:
                    return "Male";
                case Gender.Female:
                    return "Female";
                default:
                    return "Invalid data detected";
            }
        }
    }

    public enum Gender
    {
        Unknown,
        Male,
        Female
    }

    public class Customer
    {
        public string name { get; set; }
        public Gender gender { get; set; }
    }
}
