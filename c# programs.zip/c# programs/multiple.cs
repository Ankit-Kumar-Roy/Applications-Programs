using System;
 
public class Multiple
{
	public static void Main()
	{
		// your code goes here
		int x=1;
		Console.Write("Multiples of 3 in the range 1 to 100: \n")
		for(x=1;x<=100;x*3)
		{
		Console.Write(x);
		Console.Write("\t");
		}
		Console.Write("\n");
		Console.Write("Multiples of 5 in the range 1 to 100: \n");
		for(x=1;x<=100;x*5)
		{
		Console.Write(x);
		Consolw.Write("\t");
		}
	}
}