﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer Customer1 = new Customer()
            {
                ID = 101,
                Name = "Mark",
                Salary = 5000
            };
            Customer Customer2 = new Customer()
            {
                ID = 102,
                Name = "Zukerberg",
                Salary = 5500
            };
            Customer Customer3 = new Customer()
            {
                ID = 103,
                Name = "Gates",
                Salary = 6000
            };

            List<Customer> Customers = new List<Customer>();
            Customers.Add(Customer1);
            Customers.Add(Customer2);
            Customers.Add(Customer3);
            //using foreach loop
            //foreach(Customer c in Customers)
            //{
            //    Console.WriteLine("ID = {0},Name = {1},Salary = {2}", c.ID, c.Name, c.Salary);
            //}
            //using for loop
            for (int i=0; i < Customers.Count;i++ )
            {
                Customer c = Customers[i];
                Console.WriteLine("ID = {0},Name = {1},Salary = {2}", c.ID, c.Name, c.Salary);
            }
            if (Customers.Exists(cust => cust.Name.StartsWith("Z")))
            {
                Console.WriteLine("required object exists");
            }
            else
            {
                Console.WriteLine("required object doesn't exist");
            }
            Customer c1 = Customers.Find(cust=>cust.Salary>5000);
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", c1.ID, c1.Name, c1.Salary);
            }
            Customer c2 = Customers.FindLast(cust => cust.Salary > 5000);
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", c2.ID, c2.Name, c2.Salary);
            }
            List<Customer> c3 = Customers.FindAll(cust => cust.Salary > 5000);
            foreach(Customer C in c3)
            {
                Console.WriteLine("ID = {0}, Name = {1}, Salary = {2}", C.ID, C.Name, C.Salary);
            }
                Console.ReadKey();
        }
    }
    public class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }
    }
}
