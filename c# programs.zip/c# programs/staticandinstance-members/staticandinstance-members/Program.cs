﻿using System;
namespace staticandinstance_members
{

    class Circle
    {
        static float _PI;
        int _Radius;

        static Circle()
        {
            _PI = 3.141F;
            Console.WriteLine("Static Constructor called");
        }

        public Circle(int radius)
        {
            Console.WriteLine("Instance Constructor called");
            this._Radius = radius;
        }

        public float CalculateArea()
        {
            return Circle._PI * this._Radius;
        }
    }
    class Program
    {
        static void Main()
        {
            Circle c1 = new Circle(5);
            Console.WriteLine(c1.CalculateArea());
            Circle c2 = new Circle(6);
            Console.WriteLine(c2.CalculateArea());
            Console.Read();
        }
    }
}
