﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace poly
{
    class Vehicle
    {
        private int weight;
        private int topSpeed;
        private double price;
        public Vehicle()
        {

        }
        public Vehicle(int wt, int speed, double vPrice)
        {
            weight = wt;
            topSpeed = speed;
            price = vPrice;
        }
        public int getWeight()
        {
            return weight;
        }
        public int gettopSpeed()
        {
            return topSpeed;
        }
        public double getPrice()
        {
            return price;
        }
        public virtual void print()
        {
            Console.WriteLine("weight {0} kg", weight);
            Console.WriteLine("topspeed {0} km/hr", topSpeed);
            Console.WriteLine("price {0} dollar", price);
        }
    }
    class Car : Vehicle
    {
        private int numberCylinders;
        private int horsepower;
        private int displacement;
        public Car()
        {

        }
        public Car(int wt, int speed, double price, int numCylinders, int horsepowers, int displacemt)
            : base(wt, speed, price)
        {
            numberCylinders = numCylinders;
            horsepower = horsepowers;
            displacement = displacemt;
        }
        public int getNumberCylinders()
        {
            return numberCylinders;
        }
        public int getHorsePower()
        {
            return horsepower;
        }
        public int getDisplacement()
        {
            return displacement;
        }
        public override void print()
        {
            base.print();
            Console.WriteLine("cylinders {0}", numberCylinders);
            Console.WriteLine("horsepower {0}", horsepower);
            Console.WriteLine("displacement {0}", displacement);
        }
    }
    class myCar
    {
        static void Main(string[] args)
        {
            Vehicle obj = new Vehicle(15000, 120, 30000.00);
            Console.WriteLine("A vehicle");
            obj.print();
            Car objcar = new Car(3500, 100, 12000, 6, 120, 300);
            Console.WriteLine("A car");
            objcar.print();
            Console.WriteLine(" ");
            Console.ReadKey();
        }
    }
}

