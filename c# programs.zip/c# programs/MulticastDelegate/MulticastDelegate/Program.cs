﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    //multicast delegate
    //defining delegate

    delegate void MyDelegate(string m,int a,int b);
    class Program
    {
        static void Main(string[] args)
        {
            MyDelegate md = new MyDelegate(FirstMethod);
            md += new MyDelegate(SecondMethod);

            //invoke functions using delegates

            md("message A", 4, 5);
            md("message b", 7, 11);
            Console.Read();
        }
        static void FirstMethod(string s1,int x1,int y1)
        {
            Console.WriteLine("1st Method" + s1);
            int sum1 = x1 + y1;
            Console.WriteLine("sum1 = " + sum1);
        }
        static void SecondMethod(string s2, int x2, int y2)
        {
            Console.WriteLine("2nd Method" + s2);
            int sum2 = x2 + y2;
            Console.WriteLine("sum2 = " + sum2);
        }
    }
}
