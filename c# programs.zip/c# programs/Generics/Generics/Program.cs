﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            bool Equal = Calculator<string>.AreEqual("ankit", "roy");
            {
                if (Equal)
                {
                    Console.WriteLine("Equal");
                }
                else
                {
                    Console.WriteLine("Not Equal");
                }
                Console.Read();
            }
        }
        public class Calculator<T>
        {
            public static bool AreEqual(T value1, T value2)
            {
                return value1.Equals(value2);
            }
            public static T sum(T value1, T value2)
            {
                return (value1+value2);
            }
        }
    }
}

