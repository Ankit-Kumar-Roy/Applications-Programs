﻿using System;

    public class Program
    {
        public int Calculate()
        {
            int x = 2, y = 4;
           
            Console.WriteLine("enter 1-addition,2-substraction");
            int start = int.Parse(Console.ReadLine()); 
            switch(start)
            {
                case 1:
                return(x+y);             
                case 2:
                return (x - y);
                default:
                //Console.WriteLine("entered option is not available");
                return(0);

            }      
         }

        public static void Main()
        {
            Program p1 = new Program();
            int result = p1.Calculate();
            Console.WriteLine("Required result is={0}", result);
            Console.Read();
        }
    }

