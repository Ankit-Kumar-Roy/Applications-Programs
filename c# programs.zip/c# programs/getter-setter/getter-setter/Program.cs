﻿using System;

public class Student
{
    private int _id;
    private string _name;
    private int _passmark = 35;

    public void setID(int ID)
    {
        if (ID < 0)
        {
            Console.WriteLine("student id cannot be negative");
        }
        this._id = ID;
    }
    public int getID()
    {
        return this._id;
    }

    public void setName(string Name)
    {
        if (string.IsNullOrEmpty(Name))
        {
            Console.WriteLine("student name cannot be null or empty");
        }
        this._name = Name;
    }
    public string getName()
    {
        return string.IsNullOrEmpty(this._name) ? "No Name" : this._name;
    }
    
    public void PrintInfo()
    {
 Console.WriteLine("Student Id = {0} && Student Name = {1} && Student Passmark = {2}", this._id, this._name, this._passmark);
    }
}

public class Program
{
    static void Main()
    {
        Student s1 = new Student();
        s1.setID(-32);
        s1.setID(355);
        s1.setName(null);
        s1.setName("Ankit Kumar Roy");
        s1.PrintInfo();
        Console.Read();
    }
}














