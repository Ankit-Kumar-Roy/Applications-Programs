﻿using System;

//abstract classes cannot be instantiated

namespace abstractclasses
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
