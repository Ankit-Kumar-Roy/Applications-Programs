﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_Builder_4_Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            //by using "String class object.
            String userstring = "C# ";
            userstring += "video ";
            userstring += "tutorial ";
            userstring += "for ";
            userstring += "beginners ";
            Console.WriteLine(userstring);
            //Console.Read();
            //Using :"StringBuilder object.
            StringBuilder userstring1 = new StringBuilder("C#");
            userstring1.Append(" video");
            userstring1.Append(" tutorial");
            userstring1.Append(" for");
            userstring1.Append(" beginners");
            Console.WriteLine(userstring);
            //----------------------
            string userstring2 = string.Empty;
            for (int i = 1; i <= 1000; i++)
                userstring2 += i.ToString(); 
            Console.WriteLine(userstring2);

            StringBuilder userstring3 = new StringBuilder();
            for (int i = 1; i <= 1000; i++)
                userstring3.Append(i.ToString() + " ");
            Console.WriteLine(userstring2);
            Console.Read();
                
        }
    }
}
