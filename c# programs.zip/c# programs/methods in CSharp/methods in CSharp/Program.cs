﻿using System;
    class Program
    {
        static void Main(string[] args)
        {
            int sum = StaticFunc(5, 6);
            Console.WriteLine(sum);
            Program p=new Program();
            p.InstFunc();
            Console.Read();
        }
        //static method
       static int StaticFunc(int x,int y)
             {
                return(x+y);
             } 
        //instance method
         void InstFunc()
                {
                    Console.WriteLine("Enter your Number");
                    int UserNumber=int.Parse(Console.ReadLine());
                    int start=0;
                    while(start <=UserNumber)
                    {
                    Console.Write(start+" ");
                    start=start+2;
                    }
                }
      }

