﻿using ConsoleApplication1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static List<Employee> empDetail = new List<Employee>();
        static void Main(string[] args)
        {
            Int32 option1 = DisplayMainMenu();
            MainCall(option1);
            Console.Read();
        }

        /// <summary>
        /// Containing switch to handle which method to execute
        /// <param name="option">Option to Add\Delete\Update Employee Information</param>
        /// </summary>
        private static void MainCall(Int32 option)
        {
            Int32 result = 0;
            Int32 empId1 = 0;
            switch (option)
            {
                case 1:
                    AddEmployee();
                    break;
                case 2:
                    DisplayList();
                    Int32 option1 = DisplayMainMenu();
                    MainCall(option1);
                    break;
                case 3:
                    Console.WriteLine("Enter EmployeeId which you want to update:");
                    empId1 = Convert.ToInt32(Console.ReadLine());
                    result = update(empId1);
                    break;
                case 4:
                    Console.WriteLine("Enter EmployeeId which you want to delete:");
                    empId1 = Convert.ToInt32(Console.ReadLine());
                    result = DeleteEmployee(empId1);
                    if (result == 1)
                        Console.WriteLine("Employee deleted");
                    else
                        Console.WriteLine("Employee with ID:" + empId1 + " not found");
                    option1 = DisplayMainMenu();
                    MainCall(option1);
                    break;
                case 5:
                    Console.WriteLine("BYEEEEEEEEEEEEEEEEEEEEE!!!!!!!!!!!!!!!!!!!");
                    break;
                default:
                    Console.WriteLine("Invalid Input!!!!!!Re-Enter");
                    option1 =  DisplayMainMenu();
                    MainCall(option1);
                    break;
            }
        }

        /// <summary>
        /// Display Main menu
        /// </summary>
        private static int DisplayMainMenu()
        {
            Console.WriteLine("\nSelect any option:");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Display Employee");
            Console.WriteLine("3. Edit Employee");
            Console.WriteLine("4. Delete Employee");
            Console.WriteLine("5. Exit");

            Int32 option = 0;
            try
            {
                option = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception)
            {
                Console.WriteLine("Some Error Occured");
            }
            return option;
        }

        /// <summary>
        /// Add New Employee
        /// </summary>
        private static List<Employee> AddEmployee()
        {
            Employee employee = new Employee();
            try
            {
                Console.WriteLine("Enter following information to add new Employee:");
                Console.WriteLine("Enter Name");
                employee.name = Console.ReadLine();
                Console.WriteLine("Enter Emp ID (Only Numeric)");
                employee.empid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Contact(Only Numeric)");
                employee.contact = Convert.ToInt64(Console.ReadLine());
                if (empDetail.Count > 0)
                {
                    if (empDetail.Exists(emp => emp.empid == employee.empid))
                    {
                        Console.WriteLine("Employee already exists with id:" + employee.empid);
                    }
                    else
                    {
                        empDetail.Add(employee);
                    }
                }
                else
                {
                    empDetail.Add(employee);
                    Console.WriteLine("Employee successfully Added");
                }
                Console.WriteLine(@"Do you want to add more Employee? Y\N");
                char choice = Console.ReadKey().KeyChar;
                switch (Char.ToUpper(choice))
                {
                    case 'Y':
                        AddEmployee();
                        break;
                    case 'N':
                        Int32 option1 = DisplayMainMenu();
                        MainCall(option1);
                        break;
                    default:
                        Console.WriteLine("Some Error Occured!! Please select right option");
                        Console.WriteLine("-----------------------------------------------");
                        option1 = DisplayMainMenu();
                        MainCall(option1);
                        break;

                }
            }
            catch (Exception)
            {
                Console.WriteLine("Some Error Occured!! Please select right option");
                Console.WriteLine("-----------------------------------------------");
                Int32 option1 = DisplayMainMenu();
                MainCall(option1);
            }
            return empDetail;
        }

        /// <summary>
        /// Display Employee List
        /// </summary>
        private static void DisplayList(){
            Console.WriteLine("");
            Console.WriteLine("-----------------------------Employee Detail---------------------------------------");
            foreach(Employee emp in empDetail)
            {
                Console.WriteLine("Employee ID:" + emp.empid + " Name:" + emp.name + " Contact:" + emp.contact);
            }
        }

        /// <summary>
        /// Update Existing employee information
        /// </summary>
        private static Int32 update(Int32 empId)
        {
            Int32 result = 0;
            Employee employee = new Employee();
            try
            {
                var empinfo = empDetail.Where(e => e.empid == empId).FirstOrDefault();
                if (empinfo != null)
                {
                    Console.WriteLine("Enter Name");
                    employee.name = Console.ReadLine();
                    Console.WriteLine("Enter Contact(Only Numeric)");
                    employee.contact = Convert.ToInt64(Console.ReadLine());
                    empDetail.Where(e => e.empid == empId).FirstOrDefault().name = employee.name;
                    empDetail.Where(e => e.empid == empId).FirstOrDefault().contact = employee.contact;
                    Console.WriteLine("Employee with id:" + empId + "updated successfully");
                    Int32 option1 = DisplayMainMenu();
                    MainCall(option1);
                }
                else
                {
                    Console.WriteLine("Employee with id:" + empId + "does not exist");
                    Int32 option1 = DisplayMainMenu();
                    MainCall(option1);
                }
            }
            catch(Exception)
            {
                Console.WriteLine("Some Error Occured!! Please select right option");
                Console.WriteLine("-----------------------------------------------");
                Int32 option1 = DisplayMainMenu();
                MainCall(option1);
            }
            return result;
        }
        /// <summary>
        /// Delete Existing Employee
        /// <param name="empid">Which Employee Id to delete</param>
        /// </summary>
        private static int DeleteEmployee(Int32 empid)
        {
            Int32 result = empDetail.RemoveAll(e => e.empid == empid);
            return result;
        }
    }
}