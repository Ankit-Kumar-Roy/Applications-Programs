﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.Entities
{
    public class Employee
    {
        public string name { get; set; }
        public int empid { get; set; }
        public long contact { get; set; }
    }
}