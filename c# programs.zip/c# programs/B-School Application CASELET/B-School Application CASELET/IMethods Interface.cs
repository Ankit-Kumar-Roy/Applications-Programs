﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_School_Application_CASELET
{
    interface IMethods_Interface
    {
        void addStudent();
        void removeStudent();
        void getStudent();
        void getAllStudents();
        void addDepartment();
        void removeDepartment();
        void getDepartment();
        void getAllDepartments();
    }
}
