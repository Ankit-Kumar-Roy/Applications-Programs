﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace B_School_Application_CASELET
{
    public class Course
    {
        public string courseName;
        public int courseID;
        public void courseAssignFinanceandAccountsInstructors(Instructor ins)
        {
            Program p = new Program();
            Console.WriteLine("Select the course which he will teach\n1:FAC1   2:FAC2   3:FAC3   4:FAC4");
            int m = Convert.ToInt32(Console.ReadLine());
            if (m == 1)
            {
                ins.courseName = "F&ACourse1";
                ins.courseID = 101;
            }
            else if (m == 2)
            {
                ins.courseName = "F&ACourse2";
                ins.courseID = 102;
            }
            else if (m == 3)
            {
                ins.courseName = "F&ACourse1";
                ins.courseID = 103;
            }
            else
            {
                ins.courseName = "F&ACourse1";
                ins.courseID = 104;
            }
        }
        public void courseAssignStudents(Student stu)
        {

            Console.WriteLine("Select the department in which you want to add the student\n 1. Finance and Accounts     2. Sales and Management");
            int x = 0;
            bool IsInt = int.TryParse(Console.ReadLine(), out x);
            if (IsInt)
            {
                if (x == 1)
                {
                    int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
                    Console.WriteLine("you have selected Finance and Accounts department\nSelect the course in which you want to enroll the student");
                    Console.WriteLine("1: F&ACourse1    2:F&ACourse2    3:F&ACourse3    4:F&ACourse4");
                    int z = Convert.ToInt32(Console.ReadLine());
                    if (z == 1)
                    {
                        stu.courseName = "F&ACourse1";
                        stu.courseID = 101;
                        if (c1 < 15)
                        {
                            if (Program.studentsFAC1.Exists(cust => cust.studentID == stu.studentID))
                            {
                                Console.WriteLine("Entered student details exists enter another student Details");
                            }
                            else
                            {
                                Program.studentsFAC1.Add(stu);
                                c1++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("More than 15 students are not allowed");
                        }
                    }
                    else if (z == 2)
                    {
                        stu.courseName = "F&ACourse2";
                        stu.courseID = 102;
                        if (c2 < 15)
                        {
                            if (Program.studentsFAC2.Exists(cust => cust.studentID == stu.studentID))
                            {
                                Console.WriteLine("Entered student details exists enter another student Details");
                            }
                            else
                            {
                                Program.studentsFAC2.Add(stu);
                                c2++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("More than 15 students are not allowed");
                        }
                    }
                    else if (z == 3)
                    {
                        stu.courseName = "F&ACourse3";
                        stu.courseID = 103;
                        if (c3 < 15)
                        {
                            if (Program.studentsFAC3.Exists(cust => cust.studentID == stu.studentID))
                            {
                                Console.WriteLine("Entered student details exists enter another student Details");
                            }
                            else
                            {
                                Program.studentsFAC3.Add(stu);
                                c3++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("More than 15 students are not allowed");
                        }
                    }
                    else
                    {
                        stu.courseName = "F&ACourse4";
                        stu.courseID = 104;
                        if (c4 < 15)
                        {

                            if (Program.studentsFAC4.Exists(cust => cust.studentID == stu.studentID))
                            {
                                Console.WriteLine("Entered student details exists enter another student Details");
                            }
                            else
                            {
                                Program.studentsFAC4.Add(stu);
                                c4++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("More than 15 students are not allowed");
                        }
                    }
                }

                else if (x == 2)
                {
                    int c11 = 0, c22 = 0, c33 = 0, c44 = 0, c55 = 0;
                    Console.WriteLine("you have selected Sales and Management department\nSelect the course in which you want to enroll the student");
                    Console.WriteLine("1:S&mCourse1  2:S&MCourse2  3:S&MCourse3  4:S&MCourse4  5:S&MCourse5");
                    try
                    {
                        int z = Convert.ToInt32(Console.ReadLine());
                        if (z == 1)
                        {
                            stu.courseName = "S&MCourse1";
                            stu.courseID = 201;
                            if (c11 < 12)
                            {
                                if (Program.studentsSAM1.Exists(cust => cust.studentID == stu.studentID))
                                {
                                    Console.WriteLine("Entered student details exists enter another student Details");
                                }
                                else
                                {
                                    Program.studentsSAM1.Add(stu);
                                    c11++;
                                }
                            }
                            else
                            {
                                Console.WriteLine("More than 12 students are not allowed");
                            }
                        }
                        else if (z == 2)
                        {
                            stu.courseName = "S&MCourse2";
                            stu.courseID = 202;
                            if (c22 < 12)
                            {
                                if (Program.studentsSAM2.Exists(cust => cust.studentID == stu.studentID))
                                {
                                    Console.WriteLine("Entered student details exists enter another student Details");
                                }
                                else
                                {
                                    Program.studentsSAM2.Add(stu);
                                    c22++;
                                }
                            }
                            else
                            {
                                Console.WriteLine("More than 12 students are not allowed");
                            }
                        }
                        else if (z == 3)
                        {
                            stu.courseName = "S&MCourse3";
                            stu.courseID = 203;
                            if (c33 < 12)
                            {
                                if (Program.studentsSAM3.Exists(cust => cust.studentID == stu.studentID))
                                {
                                    Console.WriteLine("Entered student details exists enter another student Details");
                                }
                                else
                                {
                                    Program.studentsSAM3.Add(stu);
                                    c33++;
                                }
                            }
                            else
                            {
                                Console.WriteLine("More than 12 students are not allowed");
                            }
                        }
                        else if (z == 4)
                        {
                            stu.courseName = "S&MCourse4";
                            stu.courseID = 204;
                            if (c44 < 12)
                            {
                                if (Program.studentsSAM4.Exists(cust => cust.studentID == stu.studentID))
                                {
                                    Console.WriteLine("Entered student details exists enter another student Details");
                                }
                                else
                                {
                                    Program.studentsSAM4.Add(stu);
                                    c44++;
                                }
                            }
                            else
                            {
                                Console.WriteLine("More than 12 students are not allowed");
                            }
                        }
                        else
                        {
                            stu.courseName = "S&MCourse5";
                            stu.courseID = 205;
                            if (c55 < 12)
                            {
                                if (Program.studentsSAM1.Exists(cust => cust.studentID == stu.studentID))
                                {
                                    Console.WriteLine("Entered student details exists enter another student Details");
                                }
                                else
                                {
                                    Program.studentsSAM5.Add(stu);
                                    c55++;
                                }
                            }
                            else
                            {
                                Console.WriteLine("More than 12 students are not allowed");
                            }
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Enter valid option");
                        Student_Method_Implementation.addStudent();
                    }
                    Console.ResetColor();
                }

            }
        }
        public void courseAssignSalesandManagementInstructors(Instructor ins)
        {
            Console.WriteLine("Select the course which he will teach\n1:SAM1   2:SAM2   3:SAM3   4:SAM4   5.SAM5");
            int x = Convert.ToInt32(Console.ReadLine());
            if (x == 1)
            {
                ins.courseName = "S&MCourse1";
                ins.courseID = 201;
            }
            else if (x == 2)
            {
                ins.courseName = "S&MCourse2";
                ins.courseID = 202;
            }
            else if (x == 3)
            {
                ins.courseName = "S&MCourse3";
                ins.courseID = 203;
            }
            else if (x == 4)
            {
                ins.courseName = "S&MCourse4";
                ins.courseID = 204;
            }
            else
            {
                ins.courseName = "S&MCourse5";
                ins.courseID = 205;
            }
        }        
    }
}
