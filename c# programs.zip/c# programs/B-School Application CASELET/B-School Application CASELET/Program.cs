﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace B_School_Application_CASELET
{
    public class Program
    {
        public static string Name = "SUCCESS BUISNESS INSTITUTE";
        public static string address = "RAJENDRA NAGAR,PATNA";
        public static string phone = "5500550055";       
        public static List<Student> studentsFAC1 = new List<Student>();
        public static List<Student> studentsFAC2 = new List<Student>();
        public static List<Student> studentsFAC3 = new List<Student>();
        public static List<Student> studentsFAC4 = new List<Student>();
        public static List<Student> studentsSAM1 = new List<Student>();
        public static List<Student> studentsSAM2 = new List<Student>();
        public static List<Student> studentsSAM3 = new List<Student>();
        public static List<Student> studentsSAM4 = new List<Student>();
        public static List<Student> studentsSAM5 = new List<Student>();
        public static List<Instructor> chairpersonF_A = new List<Instructor>();
        public static List<Instructor> chairpersonS_M = new List<Instructor>();
        public static List<Instructor> Finance_and_Accounts = new List<Instructor>();
        public static List<Instructor> Sales_and_Management = new List<Instructor>();

        public enum choice
        {
            Exit,
            add_Stu,
            rem_Stu,
            get_Stu,
            get_AllStudents,
            add_Dept,
            rem_Dept,
            get_Dept,
            get_AllDept
        }

        public static void Main(string[] args)
        {
            mainMenu();
            Console.Read();
        }

        public static void mainMethod(int y)
        {
            choice selection = (choice)y;
            Department_method_implementation deptMethodCall = new Department_method_implementation();

            switch (selection)
            {
                case choice.add_Stu:
                    Student_Method_Implementation.addStudent();
                    break;
                case choice.rem_Stu:
                    Student_Method_Implementation.removeStudent();
                    break;
                case choice.get_Stu:
                    Student_Method_Implementation.getStudent();
                    break;
                case choice.get_AllStudents:
                    Student_Method_Implementation.getAllStudents();
                    break;
                case choice.add_Dept:
                    deptMethodCall.addDepartment();
                    break;
                case choice.rem_Dept:
                    deptMethodCall.removeDepartment();
                    break;
                case choice.get_Dept:
                    deptMethodCall.getDepartment();
                    break;
                case choice.get_AllDept:
                    deptMethodCall.getAllDepartments();
                    break;
                case choice.Exit:
                    break;
                default:
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.WriteLine("Sorry!!!..........You have Entered a Wrong Choice");
                    Console.ResetColor();
                    Console.BackgroundColor = ConsoleColor.DarkBlue;
                    Console.WriteLine("Do you want to Continue........Please Enter yes/no");
                    string choiceagain = Console.ReadLine().ToUpper();
                    Console.ResetColor();
                    if (choiceagain == "YES")
                    {
                        Program.mainMenu();
                        int option1;
                        bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                        if (IsInteger)
                            mainMethod(option1);
                        else
                        {
                            Console.WriteLine("Please input Numerics only");

                        }
                        Console.ResetColor();
                        Program.mainMethod(option1);
                    }                                        
                        break;                    
            }
        }

        public static void mainMenu()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Please Enter your Choice \n1: to add a student\n2: to remove a student\n3: to get a student\n4: to display or get all students\n5: to add a department\n6: to remove department\n7: to get department\n8: to get all departments\n0: Exit");
            int option1;
            bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
            if (IsInteger)
            {
                if (option1 >= 0 && option1 <= 8)
                {
                    mainMethod(option1);
                }
                else
                {
                    Console.WriteLine("Please enter the valid option");
                    mainMenu();
                }

            }
            else
            {
                Console.WriteLine("Please input Numerics only");
                mainMenu();

            }
            Console.ResetColor();
        }
    }
}
