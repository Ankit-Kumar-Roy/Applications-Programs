﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace B_School_Application_CASELET
{
    interface IDeptMethods
    {
        void addInstructor();
        void removeInstructor();
        void getInstructor();
        void getAllInstructors();
    }
    public class Department : IDeptMethods
    {
        public string name;
        int count1 = 0, count2 = 0, i1count = 0, i2count = 0;
        Program p = new Program();
        public void addInstructor()
        {           
            Course c = new Course();
            Console.WriteLine("Please select your choice\n1: To add chairperson for Finance and Accounts department\n2: To add chairperson for Sales and Management department\n3: Finance and Accounts department instructor\n4: Sales and Management department instructor");
            int x = Convert.ToInt32(Console.ReadLine());
            if (x == 1 && count1 != 1)
            {
                count1++;
                Instructor instruct = new Instructor();
                Console.WriteLine("Enter chairperson name for Finance and Accounts department");
                instruct.insName = Console.ReadLine();
                Console.WriteLine("Enter chairpersons ID");
                instruct.instructorID = Convert.ToInt32(Console.ReadLine());
                c.courseAssignFinanceandAccountsInstructors(instruct);
                Program.chairpersonF_A.Add(instruct);
            }
            else if (x == 2 && count2 != 1)
            {
                count2++;
                Instructor instruct = new Instructor();
                Console.WriteLine("Enter chairperson name for sales and management department");
                instruct.insName = Console.ReadLine();
                Console.WriteLine("Enter Instructor ID");
                instruct.instructorID = Convert.ToInt32(Console.ReadLine());
                c.courseAssignSalesandManagementInstructors(instruct);
                Program.chairpersonS_M.Add(instruct);
            }
            else if (x == 3 && i1count < 4)
            {
                i1count++;
                Instructor ins = new Instructor();
                Console.WriteLine("Enter Instructor Name");
                ins.insName = Console.ReadLine();
                Console.WriteLine("Enter Instructor ID");
                ins.instructorID = Convert.ToInt32(Console.ReadLine());
                c.courseAssignFinanceandAccountsInstructors(ins);
                Program.Finance_and_Accounts.Add(ins);
            }
            else if (x == 4 && i2count < 4)
            {
                i2count++;
                Instructor ins = new Instructor();
                Console.WriteLine("Enter Instructor Name");
                ins.insName = Console.ReadLine();
                Console.WriteLine("Enter Instructor ID");
                ins.instructorID = Convert.ToInt32(Console.ReadLine());
                c.courseAssignSalesandManagementInstructors(ins);
                Program.Sales_and_Management.Add(ins);
            }
            else if ((x == 1 && count1 == 1) || (x == 2 && count2 == 1) || (x == 3 && i1count == 3) && (x == 4 && i2count == 3))
            {
                Console.WriteLine("Sorry!!!!! You cannot add more.....reasons are...\nmore than one chairperson in an department not allowed or more than 4 instructor in an department not allowed");
            }
            Console.WriteLine("Do you want to add more?? yes/no");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "YES")
            {
                addInstructor();
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Program.mainMenu();
                int option1;
                bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                if (IsInteger)
                    Program.mainMethod(option1);
                else
                {
                    Console.WriteLine("Please input Numerics only");
                }
                Console.ResetColor();
            }
        }
        public void removeInstructor()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Enter the department name from which you want to remove the Instructor\n1: Finance and Accounts department\n2: Sales and Management department");
            if (Convert.ToInt32(Console.ReadLine()) == 1)
            {
                Console.WriteLine("Enter Instructor's ID whom you want to remove from the department");
                int remid = Convert.ToInt32(Console.ReadLine());
                bool result = Program.chairpersonF_A.Exists(cust => cust.instructorID == remid);
                if (result)
                {
                    var v = Program.Finance_and_Accounts.Find(cust => cust.instructorID == remid);
                    Program.chairpersonF_A.Remove(v);                   
                    Console.WriteLine("Chairperson of Finance & Accounts Department  Removed Successfully");
                }
                else
                {
                    var v = Program.Finance_and_Accounts.Find(cust => cust.instructorID == remid);
                    Program.Finance_and_Accounts.Remove(v);
                    Console.WriteLine("Instructor of Finance & Accounts Department Removed Successfully");
                }
            }
            else
            {
                Console.WriteLine("Enter Instructor's ID whom you want to remove from the department");
                int remid = Convert.ToInt32(Console.ReadLine());
                bool result = Program.chairpersonS_M.Exists(cust => cust.instructorID == remid);
                if (result)
                {
                    var v = Program.chairpersonS_M.Find(cust => cust.instructorID == remid);
                    Program.chairpersonS_M.Remove(v);     
                    Console.WriteLine("Chairperson of Sales and Management Department  Removed Successfully");
                }
                else
                {
                    var i2 = Program.Sales_and_Management.Find(cust => cust.instructorID == remid);
                    Program.Sales_and_Management.Remove(i2);
                    Console.WriteLine("Instructor of Sales and Management Removed Successfully");
                }

            }
            Console.WriteLine("Do you want to Remove more?? yes/no");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "YES")
            {
                removeInstructor();
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Program.mainMenu();
                int option1;
                bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                if (IsInteger)
                    Program.mainMethod(option1);
                else
                {
                    Console.WriteLine("Please input Numerics only");
                }
                Console.ResetColor();
            }

        }
        public void getInstructor()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Enter the Instructor ID whose details you want to dispaly");
            int x = Convert.ToInt32(Console.ReadLine());
            var x1 = Program.chairpersonF_A.Find(cust => cust.instructorID == x);
            var x2 = Program.chairpersonS_M.Find(cust => cust.instructorID == x);
            var x3 = Program.Finance_and_Accounts.Find(cust => cust.instructorID == x);
            var x4 = Program.Sales_and_Management.Find(cust => cust.instructorID == x);
            if (x1.instructorID == x)
            {
                Console.WriteLine("Name : {0}  ID : {1}  Course : {2}  CourseID : {3}", x1.insName, x1.instructorID, x1.courseName, x1.courseID);
            }
            else if (x2.instructorID == x)
            {
                Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", x2.insName, x2.instructorID, x2.courseName, x2.courseID);
            }
            else if (x3.instructorID == x)
            {
                Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", x3.insName, x3.instructorID, x3.courseName, x3.courseID);
            }
            else if (x4.instructorID == x)
            {
                Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", x4.insName, x4.instructorID, x4.courseName, x4.courseID);
            }
            Console.WriteLine("Do you want to select another Instructor?? yes/no");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "YES")
            {
                getInstructor();
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Program.mainMenu();
                int option1;
                bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                if (IsInteger)
                    Program.mainMethod(option1);
                else
                {
                    Console.WriteLine("Please input Numerics only");
                    Program.mainMenu();
                }
                Console.ResetColor();
            }
        }
        public void getAllInstructors()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Displaying all Instructors in the School");
            Console.WriteLine("For Finance and Accounts Department\nChairPerson Details:");
            foreach (var v in Program.chairpersonF_A)
            Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", v.insName, v.instructorID, v.courseName, v.courseID);
            Console.WriteLine("Instructor Details:");
            foreach (var v in Program.Finance_and_Accounts)
                Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", v.insName, v.instructorID, v.courseName, v.courseID);
            Console.WriteLine("For Sales and Management Department\nChairPerson Details:");
            foreach (var v in Program.chairpersonS_M)
            Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", v.insName, v.instructorID, v.courseName, v.courseID);
            Console.WriteLine("Instructor Details:");
            foreach (var v in Program.Sales_and_Management)
                Console.WriteLine("Name : {0} , ID : {1} Course : {2} CourseID : {3}", v.insName, v.instructorID, v.courseName, v.courseID);
            Console.BackgroundColor = ConsoleColor.Blue;
            Program.mainMenu();
            int option1;
            bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
            if (IsInteger)
                Program.mainMethod(option1);
            else
            {
                Console.WriteLine("Please input Numerics only");
                Program.mainMenu();
            }
            Console.ResetColor();
        }
    }
}
