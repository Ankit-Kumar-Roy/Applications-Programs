﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace B_School_Application_CASELET
{
    public class Department_method_implementation : Department
    {
        Department dispobj = new Department();
        Department depObject = new Department();
        Department deptObj1 = new Department();        
        Department deptObj2 = new Department();
        public enum select
        {
            exit,
            addInstructor,
            removeInstructor,
            getInstructor,
            getAllInstructor
        }
        public void addDepartment()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Select the Department Name to add\n1: FINANCE & ACCOUNTS     2: SALES & MANAGEMENT");
            int x = Convert.ToInt32(Console.ReadLine());
            if (x == 1)
            {
                deptObj1.name = "FINANCE AND ACCOUNTS";
            }
            else
            {
                deptObj2.name = "SALES AND AMANGEMENT";
            }
            Console.WriteLine("Department addedd successfully\nSelect your choice");
            Console.WriteLine("1. To add an Instructor  2. To remove an Instructor  3. To get an Instructor 4. to get all Instructors 0. exit");
            int y = Convert.ToInt32(Console.ReadLine());
            select key = (select)y;
            switch (key)
            {
                case select.exit:
                    break;
                case select.addInstructor:
                    depObject.addInstructor();
                    break;
                case select.removeInstructor:
                    depObject.removeInstructor();
                    break;
                case select.getInstructor:
                    depObject.getInstructor();
                    break;
                case select.getAllInstructor:
                    depObject.getAllInstructors();
                    break;
                default:
                    Console.WriteLine("Sorry!!!.........none of the Choices Matched");                    
                    break;
            }
                    Console.WriteLine("Do you want to add more? please Enter yes/no");
                    string choice = Console.ReadLine().ToUpper();
                    if (choice == "YES")
                    {
                        addDepartment();
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Program.mainMenu();
                        int option1;
                        bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                        if (IsInteger)
                            Program.mainMethod(option1);
                        else
                        {
                            Console.WriteLine("Please input Numerics only");
                        }
                        Console.ResetColor();
                    }
                    Console.ResetColor();
        }
        public void removeDepartment()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Select the Department Name to REMOVE\n1: FINANCE & ACCOUNTS     2: SALES & MANAGEMENT");
            int x = Convert.ToInt32(Console.ReadLine());
            if (x == 1)
            {
                deptObj1 = null;
                Program.studentsFAC1 = null;
                Program.studentsFAC2 = null;
                Program.studentsFAC3 = null;
                Program.studentsFAC4 = null;
                Program.Finance_and_Accounts = null;                 
            }
            else
            {
                deptObj2 = null;
                Program.studentsSAM1 = null;
                Program.studentsSAM2 = null;
                Program.studentsSAM3 = null;
                Program.studentsSAM4 = null;
                Program.studentsSAM5 = null;
                Program.Finance_and_Accounts = null;
                Program.Sales_and_Management = null;
                Program.chairpersonF_A = null;
            }
            Console.WriteLine("Do you want to Remove more? please Enter yes/no");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "YES")
            {
                removeDepartment();
            }
            else
            {
                Console.ResetColor();
                Console.BackgroundColor = ConsoleColor.Blue;
                Program.mainMenu();
                int option1;
                bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                if (IsInteger)
                    Program.mainMethod(option1);
                else
                {
                    Console.WriteLine("Please input Numerics only");
                    Program.mainMenu();
                }
                Console.ResetColor();
            }
        }
        public void getDepartment()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Select the Department Name to Display the Deatils of the Department\n1: FINANCE & ACCOUNTS     2: SALES & MANAGEMENT");
            int x = Convert.ToInt32(Console.ReadLine());
            if (x == 1)
            {
                Console.WriteLine("Department Name: {0}", deptObj1);
                Display(Program.chairpersonF_A);
                Console.WriteLine("Instructors of the Department are:");
                Display(Program.Finance_and_Accounts);
            }
            else
            {
                Console.WriteLine("Department Name: {0}", deptObj2);
                Display(Program.chairpersonS_M);
                Console.WriteLine("Instructors of the Department are:");
                Display(Program.Sales_and_Management);
            }
            Console.WriteLine("Do you want to get more department? please Enter yes/no");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "YES")
            {
                getDepartment();
            }
            else
            {
                Console.ResetColor();
                Console.BackgroundColor = ConsoleColor.Blue;
                Program.mainMenu();
                int option1;
                bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                if (IsInteger)
                    Program.mainMethod(option1);
                else
                {
                    Console.WriteLine("Please input Numerics only");
                    Program.mainMenu();
                }
                Console.ResetColor();
            }
        }
        public void getAllDepartments()
        {
            deptObj1.name = "FINANCE and ACCOUNTS";
            deptObj2.name = "SALES and MANAGEMENT";
            Console.BackgroundColor = ConsoleColor.DarkCyan; 
            Console.WriteLine("Institute name: {0},Address: {1},Phone: {2}",Program.Name,Program.address,Program.phone);
            Console.WriteLine("Department Name: {0}", deptObj1.name);
            Console.WriteLine("Chair Person Details are:");
            Display(Program.chairpersonF_A);
            Console.WriteLine("Instructors of the {0} Department are:",deptObj1.name);
            Display(Program.Finance_and_Accounts);
            Console.WriteLine("Department Name: {0}", deptObj2.name);
            Console.WriteLine("Chair Person Details are:");
            Display(Program.chairpersonS_M);
            Console.WriteLine("Instructors of the {0} Department are:",deptObj2.name);
            Display(Program.Finance_and_Accounts);
            Console.WriteLine("...............All the information displayed................");
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.Blue;
            Program.mainMenu();
            int option1;
            bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
            if (IsInteger)
                Program.mainMethod(option1);
            else
            {
                Console.WriteLine("Please input Numerics only");
                Program.mainMenu();
            }
            Console.ResetColor();
        }
        public void ChairPersonDisplay(Instructor chairinstructor)
        {
            Console.WriteLine("Name:  {0}  ID:  {1}  Course: {2}  CourseID:  {3}", chairinstructor.insName, chairinstructor.instructorID, chairinstructor.courseName, chairinstructor.courseID);
        }
        public void Display(List<Instructor> dispfun)
        {
            foreach(var v in dispfun)
            {
                Console.WriteLine("Name: {0}  ID: {1}  Course: {2}  CourseID:  {3}", v.insName, v.instructorID, v.courseName, v.courseID);
            }

        }
    }
}
