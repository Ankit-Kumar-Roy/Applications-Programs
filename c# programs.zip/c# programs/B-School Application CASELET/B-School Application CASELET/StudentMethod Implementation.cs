﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace B_School_Application_CASELET
{
    public class Student_Method_Implementation
    {
        public static void addStudent()
        {
            Course c1 = new Course();
            Student stu = new Student();
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Enter Student Name");
            stu.stuName = Console.ReadLine();
            Console.WriteLine("Enter student ID");
            stu.studentID = Convert.ToInt32(Console.ReadLine());
            c1.courseAssignStudents(stu);             
                Console.BackgroundColor = ConsoleColor.Blue;
                Program.mainMenu();
                int option1;
                bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
                if (IsInteger)
                    Program.mainMethod(option1);
                else
                {
                    Console.WriteLine("Please input Numerics only");
                    Program.mainMenu();
                }
                Console.ResetColor();
        }
        public static void removeStudent()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Enter the student ID whose details u want to delete");
            int id1 = Convert.ToInt32(Console.ReadLine());
            if (Program.studentsFAC1.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Program.studentsFAC1.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsFAC2.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC2.Find(cust => cust.studentID == id1);
                Program.studentsFAC2.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsFAC3.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC3.Find(cust => cust.studentID == id1);
                Program.studentsFAC3.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsFAC4.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC4.Find(cust => cust.studentID == id1);
                Program.studentsFAC4.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsSAM1.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsSAM1.Find(cust => cust.studentID == id1);
                Program.studentsSAM1.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsSAM2.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsSAM2.Find(cust => cust.studentID == id1);
                Program.studentsSAM2.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsSAM3.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsSAM3.Find(cust => cust.studentID == id1);
                Program.studentsSAM3.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsSAM4.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsSAM4.Find(cust => cust.studentID == id1);
                Program.studentsSAM4.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else if (Program.studentsSAM5.Exists(cust => cust.studentID == id1))

            {
                Student stu = Program.studentsSAM5.Find(cust => cust.studentID == id1);
                Program.studentsSAM5.Remove(stu);
                Console.WriteLine("Student removed Successfully..........thank u");
            }
            else
            {
                Console.WriteLine("Student doesn't exists");
            }
            Console.BackgroundColor = ConsoleColor.Blue;
            Program.mainMenu();
            int option1;
            bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
            if (IsInteger)
                Program.mainMethod(option1);
            else
            {
                Console.WriteLine("Please input Numerics only");
            }
            Console.ResetColor();
            Console.ResetColor();
        }
        public static void getStudent()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Enter the student ID whose details u want to display");
            int id1 = Convert.ToInt32(Console.ReadLine());
            if (Program.studentsFAC1.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsFAC2.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsFAC1.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsFAC1.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsSAM1.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsSAM2.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsSAM3.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsSAM4.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else if (Program.studentsSAM5.Exists(cust => cust.studentID == id1))
            {
                Student stu = Program.studentsFAC1.Find(cust => cust.studentID == id1);
                Console.WriteLine("Name : {0}   ID : {1}   Alotted Course Name : {2}   Course ID: {3}", stu.stuName, stu.studentID, stu.courseName, stu.courseID);
            }
            else
            {
                Console.WriteLine("Student doesn't exist");
            }
            Console.BackgroundColor = ConsoleColor.Blue;
            Program.mainMenu();
            int option1;
            bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
            if (IsInteger)
                Program.mainMethod(option1);
            else
            {
                Console.WriteLine("Please input Numerics only");
                Program.mainMenu();
            }
            Console.ResetColor();
        }
        public static void getAllStudents()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Details of Students of Finance and Accounts Department are:");
            foreach (var stu in Program.studentsFAC1)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsFAC2)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsFAC3)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsFAC4)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            Console.WriteLine("Details of Students SALES and MANAGEMENT Department are:");
            foreach (var stu in Program.studentsSAM1)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsSAM2)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsSAM3)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsSAM4)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            foreach (var stu in Program.studentsSAM5)
                Console.WriteLine("Name :{0}   ID :{1}   Course Alloted:{2}   Course ID:{3}", stu.stuName, stu.studentID, stu.courseID, stu.courseID);
            Console.WriteLine("Details of all the students Displayed");
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.Blue;
            Program.mainMenu();
            int option1;
            bool IsInteger = int.TryParse((Console.ReadLine()), out option1);
            if (IsInteger)
                Program.mainMethod(option1);
            else
            {
                Console.WriteLine("Please input Numerics only");
            }
            Console.ResetColor();
        }
    }
}
