﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_School_Application_CASELET
{
    public class Student:Course
    {
        public string stuName;
        public int studentID;
    }
}
