﻿/* it is much more flexible and removes the overhead involved in boxing and unboxing 
 * operations that we discussed earlier as a generic type is assigned a specific type 
 * only at run time .the type checks are done at the compile time itself.
 * hence,the generic stack in this example works much faster as compared to the non-generic counterpart.
 * the following is the implementation of a generic stack using C# Generics'.*/




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace generics
{
    public class CustomStack<S>
    {
        const int size = 10;
        private S[] register;
        public int count = 0;
        public CustomStack()
        {
            register = new S[size];
        }
        public void Push(S x)
        {
            if (count < size)
                register[count++] = x;
        }
        public S Pop()
        {
            return register[--count];

        }

    }
    public class Test
    {
        static void Main(string[] args)
        {
            CustomStack<int> intStack = new CustomStack<int>();
            intStack.Push(10);
            int i = intStack.Pop();
            Console.WriteLine(i);
            CustomStack<double> floatStack = new CustomStack<double>();
            floatStack.Push(12.25);
            double f = floatStack.Pop();
            Console.WriteLine(f);
            CustomStack<char> charStack = new CustomStack<char>();
            charStack.Push('A');
            char c = charStack.Pop();
            Console.WriteLine(c);
            Console.Read();
        }
    }
}
