﻿using System;

namespace Abstract_classes
{
    public abstract class Customer
    {
        public abstract void Print();
    }
    class Program : Customer
    {
        public override void Print()
        {
            Console.WriteLine("Print Method");
        }
        static void Main(string[] args)
        {
            Customer c = new Program();
            c.Print();
            Console.Read();
        }
    }
}
