﻿using System;

    class Program
    {
        static void Main()
        {
            Customer c1 = new Customer();
            c1.PrintFullName();
            Customer c2 = new Customer("Ankit", "Roy");
            c2.PrintFullName();
            Console.Read();

        }

        private static bool Customer()
        {
            throw new NotImplementedException();
        }
    }
    class Customer
    {
        string _firstname;
        string _lastname;
        
        public void PrintFullName()
        {
            Console.WriteLine("Full Name={0}", this._firstname + " " + this._lastname);
        }

        public Customer(string FN,string LN)
        {
            this._firstname = FN;
            this._lastname = LN;
        }

        public Customer() : this("No first name provided","No last name provided")
        {
            //this._firstname = "first name empty";
            //this._lastname = "last name empty";
        }

        ~Customer()
        {
            Console.WriteLine("Object destroyed");
        }
    }

