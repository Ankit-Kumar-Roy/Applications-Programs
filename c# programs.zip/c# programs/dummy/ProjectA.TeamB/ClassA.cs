﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectA.TeamB
{
    public class ClassA
    {
        public static void Print()
        {
            Console.WriteLine("This is team B print method");
        }
    }
}
