﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    public class Employee
    {
        //Employee obj = new Employee();
        public int empid;
        public string name;
        public long contact;

        public int ID
        { get; set; }

        public string Name
        {
            get;
            set;
        }

    }
}