﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DerivedClass dc = new DerivedClass();
            Console.Read();
        }
    }
    public class ParentClass
    {
        public ParentClass()
        {
            Console.WriteLine("Parent Class Constructor called");
        }
        public ParentClass(string Message)
        {
            Console.WriteLine(Message);
        }
    }
    public class DerivedClass:ParentClass
    {
        public DerivedClass():base("Derived class controlling parent class")
        {
            Console.WriteLine("child class constructor called");
        }
    }
}
