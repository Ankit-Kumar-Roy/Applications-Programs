﻿using System;
using PATA = ProjectA.TeamA.classA;
using PATB = ProjectA.TeamB.classA;

namespace Namespace
{
    class Program
    {
        static void Main()
        {
            //using fully qualified names
            //ProjectA.TeamA.classA.Print();
            //ProjectA.TeamB.classA.Print();
            //Console.Read();

            //using alias directives
            PATA.Print();
            PATB.Print();
            Console.Read();
        }
    }
}

namespace ProjectA
{
    namespace TeamA
    {
        class classA
        {
            public static void Print()
            {
                Console.WriteLine("This is team A print method");
            }
        }
    }
}

namespace ProjectA
{
    namespace TeamB
    {
        class classA
        {
            public static void Print()
            {
                Console.WriteLine("This is team B print method");
            }
        }
    }
}










